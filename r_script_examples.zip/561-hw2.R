#STAT 561-Homework 2 
#Author: Ozancan Ozdemir
#i
data=read.table("mpls.txt",header = T)
head(data)
#Missing values are replaced with -99.
#Let's convert them into NA
data[data==-99]=NA
head(data)
summary(data)
#summary of data set is calculated to find out which variables in the data set has missing values.
#After investigating the data set, it is seen that read.8 and math.8 have some missing values due to some unknown reasons. 
#occasion mean imputation.
#missing values are replaced by considering specific time point
library(Hmisc) 
data.imp=data #create a new data set that is exacly same with the original one
mean(data$read.8,na.rm=T)
data.imp$read.8=impute(data.imp$read.8,mean)
cbind(data.imp$read.8,data$read.8)
#When we compare the values, it is seen that the missing value at read.8 is replaced with the mean value at read. 8 which is 212.2857
#Now let's consider the other variable with missing value which is math.8
mean(data$math.8,na.rm=T)
data.imp$math.8=impute(data.imp$math.8,mean)
cbind(data.imp$math.8,data$math.8)
#The missing values at math.8 is replaced with the mean value at math.8 which equals to 226
##Fitting model 
head(data.imp)
#converting from wide to long form to conduct a model
data.imp.long =reshape(data.imp, idvar = "subid",
                      varying = c("read.5","read.6","read.7","read.8","math.5","math.6","math.7","math.8"),
                      direction = "long")
head(data.imp.long)
#It is seen that the data are converted into long format.
#Before conducting a marginal model for the data set, let us check the class of th objects in our data set 
str(data.imp.long)
#Since all categorical variables are coded as factor, we can continue with building a model
#To use in the model, find out the correlation str of the data
#To calculate it, we prefer to use wide format of the data
#take a sub sample 
math.scores=data.imp[,6:9]
cov(math.scores,use="p",m="p")
cor(math.scores,use="p",m="p")
#I suggest exchangable(symetric compund) covariance since there is no special pattern. 
#they are not even close to each other 
# Marginal models:
library(gee)
head(data.imp.long)
#order your data
osub <- order(as.integer(data.imp.long$subid))
data.imp.long=data.imp.long[osub,]
math_gee0 <- gee(math ~ gen+sped, data = data.imp.long, id = subid, family = gaussian,corstr = "exchangeable")
summary(math_gee0)


math_gee1<-gee(math~gen+sped+ell, data=data.imp.long,id=subid,family = gaussian,corstr="exchangeable")
summary(math_gee1)

