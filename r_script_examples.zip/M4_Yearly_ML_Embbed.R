############### Ozancan Ozdemir-Thesis Study ###########################

########### M4-Competition Dataset - ML Methods###################

####### This is for yearly datasets-Time Embbeding with Lag 3##################

############## No Data Preprocessing#############

setwd("C:/Users/asus/Desktop/ODT�/Tez/Analizler/Yearly Series Analysis/Yeni klas�r/originaldata_ml_lagged_version")
MyData <- read.csv(file="Yearly-train.csv", header=TRUE, sep=",") #Read Train Dataset
Yearly_Test<-read.csv(file="Yearly-test.csv", header=TRUE, sep=",") #Read Test Dataset
#set.seed(123456)
index_yearly=read.csv(file="index_yearly.csv", header=TRUE, sep=",")
index=index_yearly$x
Subset_Yearly_M4_train=MyData[index,]
Subset_Yearly_M4_train=Subset_Yearly_M4_train[,-1]#Remove The First Column
#View(Subset_Yearly_M4_train)

### Read the test data ###

Yearly_Test_indexed=Yearly_Test[index,]
Yearly_Test_indexed=Yearly_Test_indexed[,-1]

############# Support Vector Machine ############

## Create an Empty Matrix

forecastvalues_svm_embbed=array(NA, c(length(index), 6))


svm_embbed=function(x,y){
  library(e1071)
  trial=c(as.vector(na.omit(t(x))),as.numeric(y))
  trial_ts=ts(trial,frequency=1,start=1950)
  embed_data=embed(trial_ts,3)
  d=dim(embed_data)
  train=1:(d[1]-6)
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  library(randomForest)
  tuned_parameter=tune.svm(x_train,y_train,gamma = 10^(-5:-1), cost = 10^(-3:1))
  model=svm(x_train,y_train,type="eps-regression",kernel="radial",cost=tuned_parameter$best.parameters$cost,gamma=tuned_parameter$best.parameters$gamma)
  f_svm=predict(model,x_test)
  return(f_svm)
}


start_time <- Sys.time()

for(i in 1:length(index)){
  
  forecastvalues_svm_embbed[i,]=svm_embbed(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,])
}

end_time <- Sys.time()

end_time - start_time
#Time difference of 1.81297 mins

#Extracting forecast values in .csv format
write.csv(forecastvalues_svm_embbed,file="yearly_forecast_svm_embbed.csv")


################### Random Forests #####################

#Create an empty matrix
forecastvalues_rf_embbed=array(NA, c(length(index), 6))


rf_embbed=function(x,y){
  trial=c(as.vector(na.omit(t(x))),as.numeric(y))
  trial_ts=ts(trial,frequency=1,start=1950)
  embed_data=embed(trial_ts,3)
  d=dim(embed_data)
  train=1:(d[1]-6)
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  library(randomForest)
  tuned_parameter=tuneRF(x_train,y_train)
  tp_table=as.matrix(print(tuned_parameter))
  min_index=which.min(as.numeric(tp_table[,2]))
  param=as.numeric(tp_table[,1])[min_index]
  fit_rf=randomForest(x_train,y_train,mtry=param)
  f_rf=predict(fit_rf,x_test)
  return(f_rf)
}


start_time <- Sys.time()

for(i in 1:length(index)){
  
  forecastvalues_rf_embbed[i,]=rf_embbed(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,])
}

end_time <- Sys.time()

end_time - start_time
#Time difference of 11.42603 secs

#Extracting forecast values in .csv format
write.csv(forecastvalues_rf_embbed,file="yearly_forecast_rf_embbed.csv")


############XGBOOSTING##########


##Empty Matrix to store forecast values##
forecastvalues_xgb_embbed=array(NA, c(length(index), 6)) #6 represents forecast horizons

xgboost_forecast=function(x,y,h,lag,f){
  library(forecast)
  library(forecastxgb)
  trial=c(as.vector(na.omit(t(x))),as.numeric(y)) #merge train and test dataset
  trial_ts=ts(trial,frequency=f,start=1950) #read your dataset
  embed_data=embed(trial_ts,lag) #create embbed data set
  d=dim(embed_data)
  train=1:(d[1]-h) #define train dimension
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  y_train_ts=ts(y_train,frequency=f,start=1950)
  if(length(y_train_ts<24)){
    xg_model=xgbar(y_train_ts,xreg = x_train,nrounds_method = "manual")}
  else {
    xg_model=xgbar(y_train_ts,xreg = x_train)
  }
  xg_f=forecast(xg_model,xreg=x_test)
  xg_forecast=as.numeric(xg_f$mean)
  return(xg_forecast)
  
}


start_time <- Sys.time()

for(i in 1:length(index)){
  
  forecastvalues_xgb_embbed[i,]=xgboost_forecast(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,],6,3,1)
}

end_time <- Sys.time()

end_time - start_time
##Time difference of 1.593212 mins

#Extracting forecast values in .csv format
write.csv(forecastvalues_xgb_embbed,file="yearly_forecast_xgb_embbed.csv")


############ NNAR ####################

##Empty Matrix to store forecast values##
forecastvalues_nnetar_embbed=array(NA, c(length(index), 6)) #6 represents forecast horizons

nnetar_forecast_2Lag=function(x){
  library(forecast)
  data=ts(na.omit(t(x)),frequency=1,start=1950) #starting point is randomly selected.
  a=forecast(nnetar(data,p=2),h=6)
  ff=a$mean
  return(ff)
}

start_time <- Sys.time()

for(i in 1:length(index)){
  
  forecastvalues_nnetar_embbed[i,]=nnetar_forecast_2Lag(Subset_Yearly_M4_train[i,])
}

end_time <- Sys.time()

end_time - start_time
##Time difference of 10.80816 secs

#Extracting forecast values in .csv format
write.csv(forecastvalues_nnetar_embbed,file="yearly_forecast_nnetar_embbed.csv")

############### Recurrent Neural Network with Learning Rate 0.05###############

forecastvalues_rnn_0.05_embbed=array(NA, c(length(index), 6)) #6 represents forecast horizons

scaling=function(x){
  scaled=(x - min(x,na.rm = T)) / (max(x,na.rm = T) - min(x,na.rm = T))
  return(scaled)
}

rnn_forecast_embbed=function(x,y,h){
  library(rnn)
  trial=c(as.vector(na.omit(t(x))),as.numeric(y))
  trial_ts=ts(trial,frequency=1,start=1950)
  embed_data=embed(trial_ts,3)
  d=dim(embed_data)
  train=1:(d[1]-h)
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  y_train_scaled=scaling(y_train)
  x_train_scaled=scaling(x_train)
  y_test_scaled=scaling(y_test)
  x_test_scaled=scaling(x_test)
  output=cbind(y_train_scaled,x_train_scaled[,1])
  m1=trainr(Y=output,X=x_train_scaled,learningrate = 0.05,numepochs = 1000,hidden_dim = 17,network_type = "rnn")
  o=predictr(m1,x_test_scaled)
  back_forecast=(o[,1]*(max(y_test) - min(y_test)))+ min(y_test)
  back_forecast1=as.vector(t(back_forecast))
}

start_time=Sys.time()

for(i in 1:length(index)){
  forecastvalues_rnn_0.05_embbed[i,]=rnn_forecast_embbed(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,],6)
}

end_time=Sys.time()

end_time-start_time 
#Time difference of 49.5736 mins

write.csv(forecastvalues_rnn_0.05_embbed,file="yearly_forecast_rnn_0.05_embbed.csv")

############### Long Short Term Memory with Learning Rate 0.1####################

forecastvalues_lstm_0.1_embbed=array(NA, c(length(index), 6)) #6 represents forecast horizons

scaling=function(x){
  scaled=(x - min(x,na.rm = T)) / (max(x,na.rm = T) - min(x,na.rm = T))
  return(scaled)
}

lstm_forecast_embbed=function(x,y,h,f,lag){
  library(rnn)
  trial=c(as.vector(na.omit(t(x))),as.numeric(y))
  trial_ts=ts(trial,frequency=f,start=1950)
  embed_data=embed(trial_ts,lag)
  d=dim(embed_data)
  train=1:(d[1]-h)
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  y_train_scaled=scaling(y_train)
  x_train_scaled=scaling(x_train)
  y_test_scaled=scaling(y_test)
  x_test_scaled=scaling(x_test)
  output=cbind(y_train_scaled,x_train_scaled[,1])
  m1=trainr(Y=output,X=x_train_scaled,learningrate = 0.1,numepochs = 1000,hidden_dim = 17,network_type = "lstm")
  o=predictr(m1,x_test_scaled)
  back_forecast=(o[,1]*(max(y_test) - min(y_test)))+ min(y_test)
  back_forecast1=as.vector(t(back_forecast))
}

start_time=Sys.time()

for(i in 1:length(index)){
  forecastvalues_lstm_0.1_embbed[i,]=lstm_forecast_embbed(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,],6,1,3)
}

end_time=Sys.time()

end_time-start_time 
#Time difference of 1.520023 hours

write.csv(forecastvalues_lstm_0.1_embbed,file="yearly_forecast_lstm_0.1_embbed.csv")

#### Bayesian Regularized Neural Network ####

forecastvalues_brnn_embbed=array(NA, c(length(index), 6)) #6 represents forecast horizons

brnn_forecast=function(x,y,h,f,lag){
  library(brnn)
  trial=c(as.vector(na.omit(t(x))),as.numeric(y))
  trial_ts=ts(trial,frequency=f,start=1950)
  embed_data=embed(trial_ts,lag)
  d=dim(embed_data)
  train=1:(d[1]-h)
  test=(length(train)+1):d[1]
  embed_data_train=embed_data[train,]
  embed_data_test=embed_data[test,]
  y_train=embed_data_train[,1]
  x_train=embed_data_train[,-1]
  y_test=embed_data_test[,1]
  x_test=embed_data_test[,-1]
  model=brnn(x_train,y_train)
  f_brnn=predict.brnn(model,x_test)
  return(f_brnn)
}
g=1:length(index)

start_time=Sys.time()


for(i in 1:length(index)){
  forecastvalues_brnn_embbed[i,]=tryCatch(brnn_forecast(Subset_Yearly_M4_train[i,],Yearly_Test_indexed[i,],6,1,3),error=function(e) paste("something wrong here"))
}
end_time=Sys.time()
end_time-start_time


#Time difference of 6.312278 secs
#forecastvalues_brnn_lagged[96,]=brnn_forecast_2Lag(Subset_Yearly_M4_train[96,],Yearly_Test_indexed[96,])

forecastvalues_brnn_embbed[96,]=brnn_forecast(Subset_Yearly_M4_train[96,],Yearly_Test_indexed[96,],6,1,3)

#Extracting forecast values in .csv format
write.csv(forecastvalues_brnn_embbed,file="yearly_forecast_brnn_embbed.csv")


##### ACCURACY MEASURES ###########

###################SMAPE##############################


##SMAPE(1993, Makridakis)##


smape_cal <- function(outsample, forecasts){
  #Used to estimate sMAPE
  outsample <- as.numeric(outsample) ; forecasts<-as.numeric(forecasts)
  smape <- sum(((abs(outsample-forecasts))/(abs(outsample)+abs(forecasts))))*(100/3)
  return(smape)
}


ml_yearly_comparison_embbed=matrix(NA,nrow=7,ncol=5)
colnames(ml_yearly_comparison_embbed)=c("Method","SMAPE Value%","MASE Value","Comp_Time","Avg(SMAPE/100+MASE/2)")
ml_yearly_comparison_embbed[,1]=c("svm_embbed","rf_embbed","xgb_embbed","nnetar_embbed","RNN_0.05","LSTM_0.1","brnn_embbed")
ml_yearly_comparison_embbed[,4]=c("0.0302hour","0.0032hour","0.0265hour","0.003hour","0.8263hour","1.52hour","0.0018hour")

##svm_embbed-Smape###

sum_svm_embbed_smape=0

for( i in 1:length(index)){
  sum_svm_embbed_smape=sum_svm_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_svm_embbed[i,])
}
svm_embbed_smape=(sum_svm_embbed_smape)/length(index)
ml_yearly_comparison_embbed[1,2]=svm_embbed_smape

##rf_embbed-Smape###

sum_rf_embbed_smape=0

for( i in 1:length(index)){
  sum_rf_embbed_smape=sum_rf_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_rf_embbed[i,])
}
rf_embbed_smape=(sum_rf_embbed_smape)/length(index)
ml_yearly_comparison_embbed[2,2]=rf_embbed_smape


##xgb_embbed-Smape###

sum_xgb_embbed_smape=0

for( i in 1:length(index)){
  sum_xgb_embbed_smape=sum_xgb_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_xgb_embbed[i,])
}
xgb_embbed_smape=(sum_xgb_embbed_smape)/length(index)
ml_yearly_comparison_embbed[3,2]=xgb_embbed_smape

##nnetar_embbed-Smape###

sum_nnetar_embbed_smape=0

for( i in 1:length(index)){
  sum_nnetar_embbed_smape=sum_nnetar_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_nnetar_embbed[i,])
}
nnetar_embbed_smape=(sum_nnetar_embbed_smape)/length(index)
ml_yearly_comparison_embbed[4,2]=nnetar_embbed_smape


##rnn_0.05_embbed-Smape### (best one)

sum_rnn_0.05_embbed_smape=0

for( i in 1:length(index)){
  sum_rnn_0.05_embbed_smape=sum_rnn_0.05_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_rnn_0.05_embbed[i,])
}
rnn_0.05_embbed_smape=(sum_rnn_0.05_embbed_smape)/length(index)
ml_yearly_comparison_embbed[5,2]=rnn_0.05_embbed_smape


##LSTM_0.1-Smape### (best one)

sum_lstm_0.1_embbed_smape=0

for( i in 1:length(index)){
  sum_lstm_0.1_embbed_smape=sum_lstm_0.1_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_lstm_0.1_embbed[i,])
}
lstm_0.1_embbed_smape=(sum_lstm_0.1_embbed_smape)/length(index)
ml_yearly_comparison_embbed[6,2]=lstm_0.1_embbed_smape


##brnn_embbed-Smape### 

sum_brnn_embbed_smape=0

for( i in 1:length(index)){
  sum_brnn_embbed_smape=sum_brnn_embbed_smape+smape_cal(Yearly_Test_indexed[i,],forecastvalues_brnn_embbed[i,])
}
brnn_embbed_smape=(sum_brnn_embbed_smape)/length(index)
ml_yearly_comparison_embbed[7,2]=brnn_embbed_smape

############################ MASE ################################3


##MASE(2006, Rob J Hyndman)##

mase_cal <- function(insample, outsample, forecasts){
  #Used to estimate MASE
  frq <- frequency(insample)
  forecastsNaiveSD <- rep(NA,frq)
  for (j in (frq+1):length(insample)){
    forecastsNaiveSD <- c(forecastsNaiveSD, insample[j-frq])
  }
  masep<-(sum(abs(insample-forecastsNaiveSD),na.rm = TRUE))/(length(insample)-frq)
  
  outsample <- as.numeric(outsample) ; forecasts <- as.numeric(forecasts)
  
  mase_pre <- sum(abs(outsample-forecasts))/masep
  mase=mase_pre/6
  return(mase)
}

##svm_embbed-mase###

sum_svm_embbed_mase=0

for( i in 1:length(index)){
  sum_svm_embbed_mase=sum_svm_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_svm_embbed[i,])
}
svm_embbed_mase=(sum_svm_embbed_mase)/length(index)
ml_yearly_comparison_embbed[1,3]=svm_embbed_mase

##rf_embbed-mase###

sum_rf_embbed_mase=0

for( i in 1:length(index)){
  sum_rf_embbed_mase=sum_rf_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_rf_embbed[i,])
}
rf_embbed_mase=(sum_rf_embbed_mase)/length(index)
ml_yearly_comparison_embbed[2,3]=rf_embbed_mase


##xgb_embbed-mase###

sum_xgb_embbed_mase=0

for( i in 1:length(index)){
  sum_xgb_embbed_mase=sum_xgb_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_xgb_embbed[i,])
}
xgb_embbed_mase=(sum_xgb_embbed_mase)/length(index)
ml_yearly_comparison_embbed[3,3]=xgb_embbed_mase

##nnetar_embbed-mase###

sum_nnetar_embbed_mase=0

for( i in 1:length(index)){
  sum_nnetar_embbed_mase=sum_nnetar_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_nnetar_embbed[i,])
}
nnetar_embbed_mase=(sum_nnetar_embbed_mase)/length(index)
ml_yearly_comparison_embbed[4,3]=nnetar_embbed_mase



##rnn_0.05_embbed-mase### (best one)

sum_rnn_0.05_embbed_mase=0

for( i in 1:length(index)){
  sum_rnn_0.05_embbed_mase=sum_rnn_0.05_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_rnn_0.05_embbed[i,])
}
rnn_0.05_embbed_mase=(sum_rnn_0.05_embbed_mase)/length(index)
ml_yearly_comparison_embbed[5,3]=rnn_0.05_embbed_mase



##LSTM_0.1-embbed-mase### (best one)

sum_lstm_0.1_embbed_mase=0

for( i in 1:length(index)){
  sum_lstm_0.1_embbed_mase=sum_lstm_0.1_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_lstm_0.1_embbed[i,])
}
lstm_0.1_embbed_mase=(sum_lstm_0.1_embbed_mase)/length(index)
ml_yearly_comparison_embbed[6,3]=lstm_0.1_embbed_mase


##brnn_embbed-mase### 

sum_brnn_embbed_mase=0

for( i in 1:length(index)){
  sum_brnn_embbed_mase=sum_brnn_embbed_mase+mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_brnn_embbed[i,])
}
brnn_embbed_mase=(sum_brnn_embbed_mase)/length(index)
ml_yearly_comparison_embbed[7,3]=brnn_embbed_mase


Smape=c(svm_embbed_smape,rf_embbed_smape,xgb_embbed_smape,nnetar_embbed_smape,rnn_0.05_embbed_smape,lstm_0.1_embbed_smape,brnn_embbed_smape)/100
masevalues=c(svm_embbed_mase,rf_embbed_mase,xgb_embbed_mase,nnetar_embbed_mase,rnn_0.05_embbed_mase,lstm_0.1_embbed_mase,brnn_embbed_mase)
ml_yearly_comparison_embbed[,5]=(Smape+masevalues)/2

ml_yearly_comparison_embbed

#Method          SMAPE Value%       MASE Value         Comp_Time    Avg(SMAPE/100+MASE/2)
#[1,] "svm_embbed"    "15.0179679313391" "3.27064658999769" "0.0302hour" "1.71041313465554"   
#[2,] "rf_embbed"     "19.2293121313613" "4.51646296852997" "0.0032hour" "2.35437804492179"   
#[3,] "xgb_embbed"    "17.9053856396909" "3.93716231891376" "0.0265hour" "2.05810808765534"   
#[4,] "nnetar_embbed" "22.9969146018941" "5.19203087577599" "0.003hour"  "2.71100001089747"   
#[5,] "RNN_0.05"      "5.48241120782779" "1.15999108892674" "0.8263hour" "0.607407600502507"  
#[6,] "LSTM_0.1"      "8.00789551674008" "1.884986834444"   "1.52hour"   "0.9825328948057"    
#[7,] "brnn_embbed"   "12.0889993126439" "2.49507152756936" "0.0018hour" "1.3079807603479"    



####BOXPLOTDATA############


##svm_embbed-Smape###

svm_embbed_smape_values=c()

for( i in 1:length(index)){
  svm_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_svm_embbed[i,])
}


##rf_embbed-Smape###

rf_embbed_smape_values=c()

for( i in 1:length(index)){
  rf_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_rf_embbed[i,])
}


##xgb_embbed-Smape###

xgb_embbed_smape_values=c()

for( i in 1:length(index)){
  xgb_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_xgb_embbed[i,])
}

##nnetar_embbed-Smape###

nnetar_embbed_smape_values=c()

for( i in 1:length(index)){
  nnetar_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_nnetar_embbed[i,])
}

##rnn_0.05_embbed-Smape### (best one)

rnn_0.05_embbed_smape_values=c()

for( i in 1:length(index)){
  rnn_0.05_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_rnn_0.05_embbed[i,])
}


##LSTM_0.1-Smape### (best one)

lstm_0.1_embbed_smape_values=c()

for( i in 1:length(index)){
  lstm_0.1_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_lstm_0.1_embbed[i,])
}


##brnn_embbed-Smape### 

brnn_embbed_smape_values=c()

for( i in 1:length(index)){
  brnn_embbed_smape_values[i]=smape_cal(Yearly_Test_indexed[i,],forecastvalues_brnn_embbed[i,])
}

############################ MASE ################################3


##MASE(2006, Rob J Hyndman)##

mase_cal <- function(insample, outsample, forecasts){
  #Used to estimate MASE
  frq <- frequency(insample)
  forecastsNaiveSD <- rep(NA,frq)
  for (j in (frq+1):length(insample)){
    forecastsNaiveSD <- c(forecastsNaiveSD, insample[j-frq])
  }
  masep<-(sum(abs(insample-forecastsNaiveSD),na.rm = TRUE))/(length(insample)-frq)
  
  outsample <- as.numeric(outsample) ; forecasts <- as.numeric(forecasts)
  
  mase_pre <- sum(abs(outsample-forecasts))/masep
  mase=mase_pre/6
  return(mase)
}

##svm_embbed-mase###

svm_embbed_mase_values=c()

for( i in 1:length(index)){
  svm_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_svm_embbed[i,])
}


##rf_embbed-mase###

rf_embbed_mase_values=c()

for( i in 1:length(index)){
  rf_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_rf_embbed[i,])
}


##xgb_embbed-mase###

xgb_embbed_mase_values=c()

for( i in 1:length(index)){
  xgb_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_xgb_embbed[i,])
}

##nnetar_embbed-mase###

nnetar_embbed_mase_values=c()

for( i in 1:length(index)){
  nnetar_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_nnetar_embbed[i,])
}


##rnn_0.05_embbed-mase### (best one)

rnn_0.05_embbed_mase_values=c()

for( i in 1:length(index)){
  rnn_0.05_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_rnn_0.05_embbed[i,])
}


##LSTM_0.1-embbed-mase### (best one)

lstm_0.1_embbed_mase_values=c()

for( i in 1:length(index)){
  lstm_0.1_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_lstm_0.1_embbed[i,])
}

##brnn_embbed-mase### 

brnn_embbed_mase_values=c()

for( i in 1:length(index)){
  brnn_embbed_mase_values[i]=mase_cal(ts(na.omit(t(Subset_Yearly_M4_train[i,])),frequency=1,start=1950),Yearly_Test_indexed[i,],forecastvalues_brnn_embbed[i,])
}


boxplot_data_ml=cbind(svm_embbed_smape_values,rf_embbed_smape_values,xgb_embbed_smape_values,nnetar_embbed_smape_values,rnn_0.05_embbed_smape_values,lstm_0.1_embbed_smape_values,brnn_embbed_smape_values,svm_embbed_mase_values,rf_embbed_mase_values,xgb_embbed_mase_values,nnetar_embbed_mase_values,rnn_0.05_embbed_mase_values,lstm_0.1_embbed_mase_values,brnn_embbed_mase_values,(((svm_embbed_smape_values/100)+svm_embbed_mase_values)/2),(((rf_embbed_smape_values/100)+rf_embbed_mase_values)/2),(((xgb_embbed_smape_values/100)+xgb_embbed_mase_values)/2),(((nnetar_embbed_smape_values/100)+nnetar_embbed_mase_values)/2),(((rnn_0.05_embbed_smape_values/100)+rnn_0.05_embbed_mase_values)/2),(((lstm_0.1_embbed_smape_values/100)+lstm_0.1_embbed_mase_values)/2),(((brnn_embbed_smape_values/100)+brnn_embbed_mase_values)/2))
write.csv(boxplot_data_ml,file="boxplot_data_ml.csv")
