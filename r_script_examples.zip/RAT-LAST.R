##Rat-Tumors Example##
#Rat Tumor Example
data <- read.table("rat-tumors.txt",header=T)

y <- data$y
n <- data$N
J <- length(y)
head(data)

##############################################################

log.prior <- function(alpha,beta) {
  {-2.5}*log(alpha + beta)
}

draw.thetas <- function(alpha,beta) {
  return(rbeta(J,alpha+y,beta+n-y))
}

draw.alpha <- function(alpha,beta,theta,prop.sd) {
  alpha.star <- rnorm(1,alpha,prop.sd)
  if (alpha.star<0) { alpha.star <- 0 }
  num <- J*(lgamma(alpha.star+beta) - lgamma(alpha.star)) +
    alpha.star*sum(log(theta)) + log.prior(alpha.star,beta)
  den <- J*(lgamma(alpha+beta)      - lgamma(alpha)) +
    alpha     *sum(log(theta)) + log.prior(alpha,beta)
  # print(c(alpha,alpha.star,num,den))
  acc <- ifelse(log(runif(1))<=num - den,1,0)
  alpha.acc <<- alpha.acc + acc
  return(ifelse(acc,alpha.star,alpha))
}

draw.beta <- function(alpha,beta,theta,prop.sd) {
  beta.star <- rnorm(1,beta,prop.sd)
  if (beta.star<0) { beta.star <- 0 }
  num <- J*(lgamma(alpha+beta.star) - lgamma(beta.star)) +
    beta.star*sum(log(1-theta)) + log.prior(alpha,beta.star)
  den <- J*(lgamma(alpha+beta)      - lgamma(beta)) +
    beta     *sum(log(1-theta)) + log.prior(alpha,beta)
  # print(c(beta,beta.star,num,den))
  acc <- ifelse(log(runif(1))<=num - den,1,0)
  beta.acc <<- beta.acc + acc
  
  return(ifelse(acc,beta.star,beta))
}

################################################################  

# B <- 0
# M <- 1000

run.chain <- function(a.start,b.start,B=0,M) {
  
  MM <- B + M
  
  alpha <- matrix(NA,MM)
  beta <- matrix(NA,MM)
  theta <- matrix(NA,nrow=MM,ncol=J)
  
  # Metropolis tuning parameters
  alpha.prop.sd <- 0.5
  beta.prop.sd <- 3
  
  # Initial values for the chain
  alpha[1] <- a.start
  beta[1] <- b.start
  theta[1,] <- draw.thetas(alpha[1],beta[1]) # or theta[1,] <- (y+.5)/(n+.5)
  
  # Monitor acceptance frequency
  alpha.acc <<- 0
  beta.acc <<- 0
  
  # MCMC simulation
  for (m in 2:MM) {
    alpha[m] <- draw.alpha(alpha[m-1],beta[m-1],theta[m-1,],alpha.prop.sd)
    beta[m] <- draw.beta(alpha[m],beta[m-1],theta[m-1,],beta.prop.sd)
    theta[m,] <- draw.thetas(alpha[m],beta[m])
  }
  
  good <- (B+1):MM
  
  return(list(alpha=alpha[good],beta=beta[good],theta=theta[good,],
              alpha.rate=alpha.acc/MM,beta.rate=beta.acc/MM))
  
}

#CHAIN1#
chain1<-run.chain(a.start=0.5,b.start=0.5,M=10000)
alpha.mcmc <- chain1$alpha
beta.mcmc <- chain1$beta
theta.mcmc <- chain1$theta
alpha.rate <- chain1$alpha.rate
beta.rate <- chain1$beta.rate
#CHAIN2#
chain2<-run.chain(a.start=0.05,b.start=0.05,M=10000)
alpha.mcmc2 <- chain2$alpha
beta.mcmc2 <- chain2$beta
theta.mcmc2 <- chain2$theta
alpha.rate2 <- chain2$alpha.rate
beta.rate2 <- chain2$beta.rate
##We are considering theta values##
##est.theta##
estimated.theta<-c()
for( i in 1:71){
  estimated.theta[i]<-sum(theta.mcmc[,i][1001:10000]+theta.mcmc2[,i][1001:10000])/18000
}
estimated.theta
##sd##
standard.error<-c()
for(i in 1:71){
  standard.error[i]<-sd(c(theta.mcmc[,i][1001:10000],theta.mcmc2[,i][1001:10000]))
}
standard.error
##mc error##
#formula=s/N^1/2
mc.error<-c()
for(i in 1:71){
  mc.error[i]<-sd(c(theta.mcmc[,i][1001:10000],theta.mcmc2[,i][1001:10000]))/sqrt(18000)
}
mc.error
##median##
medianvalues<-c()
for(i in 1:71){
  medianvalues[i]<-median(c(theta.mcmc[,i][1001:10000],theta.mcmc2[,i][1001:10000]))
}

tab<-data.frame(estimated.theta,standard.error,mc.error,medianvalues)
head(tab)
#####graphs#####
##traceplot##
par(mfrow=c(3,2))
iteration=1:10000
for(i in 1:6){
  plot(iteration,theta.mcmc[,i],type="l",col="red",ylab="theta",main="Trace Plot") #chain1
  lines(iteration,theta.mcmc2[,i],type="l",col="blue") #chain2
}
##acf##
acf(theta.mcmc[,1],10000,main="ACF for theta1 from Chain1")
acf(theta.mcmc2[,1],10000,main="ACF for theta1 from Chain2")
acf(theta.mcmc[,2],10000,main="ACF for theta2 from Chain1")
acf(theta.mcmc2[,2],10000,main="ACF for theta2 from Chain2")
acf(theta.mcmc[,3],10000,main="ACF for theta3 from Chain1")
acf(theta.mcmc2[,3],10000,main="ACF for theta3 from Chain2")
##density##
par(mfrow=c(3,2))
plot(density(c(theta.mcmc[,1][1001:10000],theta.mcmc2[,1][1001:10000])),xlab="p1",main="Density Plot")
plot(density(c(theta.mcmc[,2][1001:10000],theta.mcmc2[,2][1001:10000])),xlab="p2",main="Density Plot")
plot(density(c(theta.mcmc[,3][1001:10000],theta.mcmc2[,3][1001:10000])),xlab="p3",main="Density Plot")
plot(density(c(theta.mcmc[,4][1001:10000],theta.mcmc2[,4][1001:10000])),xlab="p4",main="Density Plot")
plot(density(c(theta.mcmc[,5][1001:10000],theta.mcmc2[,5][1001:10000])),xlab="p5",main="Density Plot")
plot(density(c(theta.mcmc[,6][1001:10000],theta.mcmc2[,6][1001:10000])),xlab="p6",main="Density Plot")
###bgr##
R.hat <- function(phi) {
  
  M <- dim(phi)[1]
  R <- dim(phi)[2]
  
  phi.dot <- apply(phi,2,mean)
  phi.dotdot <- mean(phi)
  
  # print(round(c(pd=phi.dot,pdd=phi.dotdot),2))
  # scan()
  
  B <- (M/(R-1))*sum((phi.dot - phi.dotdot)^2)
  
  s2 <- (sweep(phi,2,phi.dot,"-"))^2
  
  W <- sum(s2)/(R*(M-1))
  
  varplus <- (M-1)*W/M + B/M
  varminus <- W
  
  # print(round(c(B=B,W=W,vp=varplus,vm=varminus),2))
  # scan()
  
  return(sqrt(varplus/varminus))
  
}

R.th <- rep(NA,J)

for (j in 1:J) {
  R.th[j] <- R.hat(theta[,j,])
}
R.th
######################################################
##corr##
phat=read.table("phat.txt")
cor(tab$estimated.theta,phat$V1)
